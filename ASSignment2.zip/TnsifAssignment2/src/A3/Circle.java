package A3;


import java.util.Scanner;

public class Circle {

    // Data members
    double radius;
    String colour;

    // Method to get input
    void getInput() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter radius: ");
        radius = sc.nextDouble();
        sc.nextLine(); // consume newline
        System.out.print("Enter colour: ");
        colour = sc.nextLine();
    }

    // Method to calculate and display area
    void calcArea() {
        double area = Math.PI * radius * radius;
        System.out.println("Area of Circle: " + area);
    }

    public static void main(String[] args) {
        Circle c = new Circle();
        c.getInput();
        c.calcArea();
    }
}
