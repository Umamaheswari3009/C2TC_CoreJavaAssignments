package A2;


import java.util.Scanner;

public class StudentDetails {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        // Input
        String name = sc.nextLine();
        int rollNumber = sc.nextInt();
        String grade = sc.next();
        String percentage = sc.next();

        // Output
        System.out.println(name);
        System.out.println(rollNumber);
        System.out.println(grade);
        System.out.println(percentage);

        sc.close();
    }
}