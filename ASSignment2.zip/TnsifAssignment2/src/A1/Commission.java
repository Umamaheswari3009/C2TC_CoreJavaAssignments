package A1;


import java.util.Scanner;

public class Commission {

    // Data Members
    String name;
    String address;
    String phone;
    double sales_amount;
    double commission;

    // Default Constructor
    Commission() {
        System.out.println("Student object is created");
    }

    // Method to accept details
    void acceptDetails() {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter Name:");
        name = sc.nextLine();

        System.out.println("Enter Address:");
        address = sc.nextLine();

        System.out.println("Enter Phone:");
        phone = sc.nextLine();

        System.out.println("Enter Sales Amount:");
        sales_amount = sc.nextDouble();
    }

    // Method to calculate commission
    void calculateCommission() {

        if (sales_amount >= 100000) {
            commission = sales_amount * 0.10;
        } 
        else if (sales_amount >= 50000) {
            commission = sales_amount * 0.05;
        } 
        else if (sales_amount >= 30000) {
            commission = sales_amount * 0.03;
        } 
        else {
            commission = 0;
        }

        // Display details
        System.out.println("\n--- Employee Details ---");
        System.out.println("Name: " + name);
        System.out.println("Address: " + address);
        System.out.println("Phone: " + phone);
        System.out.println("Sales Amount: " + sales_amount);
        System.out.println("Commission: " + commission);
    }

    // Main Method
    public static void main(String[] args) {

        Commission c = new Commission(); // object creation
        c.acceptDetails();
        c.calculateCommission();
    }
}