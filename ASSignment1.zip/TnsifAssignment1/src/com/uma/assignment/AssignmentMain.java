package com.uma.assignment;
import com.uma.assignment.employees.Manager;
import com.uma.assignment.employees.Developer;
import com.uma.assignment.utilities.EmployeeUtilities;

public class AssignmentMain {

    public static void main(String[] args) {

        Manager manager = new Manager("Ravi", 101, 50000, "HR");
        Developer developer = new Developer("Anu", 102, 40000, "Java");

        EmployeeUtilities.displayEmployee(manager);
        System.out.println("-------------------");
        EmployeeUtilities.displayEmployee(developer);
    }
}
