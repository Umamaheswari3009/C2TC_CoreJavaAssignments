
package com.uma.assignment.utilities;

import com.uma.assignment.employees.Employee;

/**
 * Utility class for employee operations
 */
public class EmployeeUtilities {

    public static void displayEmployee(Employee emp) {
        System.out.println("Name: " + emp.getName());
        System.out.println("ID: " + emp.getEmployeeId());
        System.out.println("Salary: " + emp.getSalary());
    }
}
