
package com.uma.assignment.employees;

/**
 * Developer subclass
 */
public class Developer extends Employee {

    private String programmingLanguage;

    public Developer(String name, int id, double salary, String language) {
        super(name, id, salary);
        this.programmingLanguage = language;
    }

    public String getProgrammingLanguage() {
        return programmingLanguage;
    }
}
