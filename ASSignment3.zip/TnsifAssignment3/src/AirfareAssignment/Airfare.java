package AirfareAssignment;

public interface Airfare {



    double calculateAmount();
}
